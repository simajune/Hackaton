
import UIKit
import Firebase
import CountdownLabel

class MainViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //카운드 다운 셋팅
        let countDownlabel = CountdownLabel(frame: CGRect(x: 0, y: (3 * view.frame.height) / 4, width: view.frame.width, height: 100), minutes: 10)
        countDownlabel.textAlignment = .center
        self.view.addSubview(countDownlabel)
        countDownlabel.countdownDelegate = self
        
        countDownlabel.start()
    }
    
    
    
}

extension MainViewController: CountdownLabelDelegate {
    func countdownFinished() {
        print("finished")
    }
}
